package me.olliem5.past.impl.modules.core;

import me.olliem5.past.api.module.Category;
import me.olliem5.past.api.module.Module;
import me.olliem5.past.api.module.ModuleInfo;

@ModuleInfo(name = "Capes", description = "Controls the usage of client capes", category = Category.CORE)
public class Capes extends Module {
}
