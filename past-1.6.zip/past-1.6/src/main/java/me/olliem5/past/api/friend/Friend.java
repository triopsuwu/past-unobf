package me.olliem5.past.api.friend;

public class Friend {
    public String name;

    public Friend(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
